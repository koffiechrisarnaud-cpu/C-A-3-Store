# C-A 3 Store

Site vitrine Next.js (App Router) qui regroupe les boutiques Chariow.

## Lancer en local
    npm install
    npm run dev        # http://localhost:3000

## Modifier le contenu
Tout est dans `data/stores.js` : liens, prix, descriptions, images.
Les images vont dans `public/covers/` (ex. `img: "/covers/glow.jpg"`).

## Mettre en ligne
1. Pousser le dossier sur GitHub.
2. Sur vercel.com : « Add New Project », choisir le dépôt, puis Deploy (aucun réglage nécessaire).
